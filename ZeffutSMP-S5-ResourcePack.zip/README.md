# Pack de ressources — Saison 5 « Ascension »

Un modèle de masse par palier, adressé par le composant vanilla `minecraft:item_model`.
Le plugin pose la clé `zeffsmp:mace_<palier>` sur chaque masse ; ce pack fournit le modèle en face.

## État actuel

Le pack est **complet et fonctionnel** : dix modèles 3D, dix textures, dix définitions d'objet,
et les clés correspondent au code.

| Paliers | Modèle | Géométrie |
|---|---|---|
| 0 à 8 (Brute → Netherite) | le même pour tous | *Mace 3D* — **Nestter**, 4 éléments |
| 9 (Masse Divine) | le gros modèle | *OPD's Better Mace* — **OPDirect**, 9 éléments |

**La forme ne change qu'une fois.** Sur les neuf premiers paliers, seule la couleur progresse ; la
Masse Divine est la seule à se transformer. C'est ce qui fait de son apparition un événement.

La couleur change à chaque palier : teinte, saturation **et luminosité** issues de
`MaceTier.colorMM()`. La luminosité compte autant que la teinte — trois paliers sont des gris
(Brute, Pierre, Fer) et sans elle, ils ressortent identiques en jeu.

## Régénérer

```bash
python3 ../outils/generer-pack-masses.py
```

Tout est généré : géométrie et textures. **Ne modifie pas les fichiers à la main**, la prochaine
exécution les écraserait. Pour changer une couleur, change-la dans `MaceTier.java` **et** dans
`PALIERS` en tête du script — les deux doivent rester d'accord.

Le script lit les deux `.zip` de `sources/`. Sans eux, il s'arrête avec un message explicite.

## Crédits

Les géométries proviennent de deux packs CurseForge, repris avec leur champ `credit` d'origine
intact dans chaque modèle :

- **Mace 3D** — Nestter — https://www.curseforge.com/minecraft/texture-packs/mace-3d-by-nestter
- **OPD's Better Mace** — OPDirect — https://www.curseforge.com/minecraft/texture-packs/opds-better-mace

Les deux sont publiés en *All Rights Reserved*. Le pack est servi **uniquement aux joueurs du
serveur** et n'est republié sur aucun catalogue public : c'est ce qui sépare cet usage privé d'une
redistribution. Ces crédits restent visibles ici et dans la description du pack.

## Les dix clés

`mace_brute`, `mace_bois`, `mace_pierre`, `mace_cuivre`, `mace_or`, `mace_fer`, `mace_diamant`,
`mace_emeraude`, `mace_netherite`, `mace_divine`

Elles sont produites par `MaceTier.modelKey()` : renommer un fichier sans renommer l'enum fait
retomber l'affichage sur la masse vanilla, **sans aucune erreur côté serveur**.
